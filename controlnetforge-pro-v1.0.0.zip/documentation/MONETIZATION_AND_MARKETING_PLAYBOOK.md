# ControlNetForge Pro - Commercial & Monetization Strategy Playbook

## 1. Product Positioning & Market Demand
ControlNet (ODVA CIP / IEC 61158 Type 2) is a specialized, deterministic industrial network with millions of active nodes across:
- **Automotive Stamping & Powertrain**: General Motors, Ford, Stellantis, Chrysler body-on-frame assembly.
- **Continuous Web & Converting Processing**: High-speed printing presses, papermaking machines, and steel rolling mills requiring zero-jitter I/O synchronization.
- **Water Treatment & Chemical Batching**: Remote pump stations and hazardous area I/O drops utilizing Rockwell 1756 ControlLogix and 1794 Flex I/O architectures.

### Key Engineering Pain Points Solved
- Rockwell RSNetWorx for ControlNet is an expensive, license-locked software tool that requires complex EDS file registries and is difficult to deploy on modern Windows laptops.
- Controls engineers troubleshooting ControlNet nodes face mysterious communication drops caused by non-binary RPI values, SMax misalignments, or RG-6 cable attenuation exceeding the 13.3 dB threshold.
- Adding a single node often requires recalculating the entire NUT schedule to prevent SSP overruns (>75%).

**ControlNetForge Pro** provides a lightweight, zero-install, browser-based and CLI workbench for rapid diagnostics, pre-commissioning calculations, and automated schedule auditing.

---

## 2. Pricing Tiers & Commercial Model

| Tier | Target Customer | Pricing | Key Inclusions |
| :--- | :--- | :--- | :--- |
| **Community Edition** | Students, apprentices, plant technicians | Free / Open Core | Frame Builder, Dissector, Basic NUT Calculator, Web UI |
| **Professional License** | Controls Engineers, System Integrators | $299 one-time per seat | Full NUT Bandwidth Allocator, 10-Point Safety Auditor, Python CLI, RSNetWorx & Studio 5000 Exporters |
| **Plant Site License** | Automotive OEMs, Paper/Steel Mills | $2,490 / facility / year | Site-wide multi-seat license, automated CI/CD schedule verification hooks, priority technical support |

---

## 3. Go-To-Market & Acquisition Channels
1. **Automation & PLC Communities**: PLCS.net, Reddit r/PLC, and MrPLC forums discussing ControlNet migration and troubleshooting.
2. **Open Source SEO & Developer Tools**: GitHub repository for `controlnet-cli.py` optimized for search terms: "ControlNet NUT calculator", "RSNetWorx schedule CSV generator", "RG-6 coaxial tap loss calculator", "ControlNet SMax UMax explanation".
3. **Rockwell Automation Systems Integrator Outreach**: Direct marketing to controls engineering firms handling legacy ControlLogix to EtherNet/IP migration projects.
4. **Plant Maintenance Quick Reference Guides**: Distributable PDF cheat sheets on "ControlNet RG-6 Attenuation Rules & NUT Sizing" co-branded with ControlNetForge Pro.

# ControlNetForge Pro - Technical Architecture & Protocol Specification

## 1. Executive Summary & Purpose
**ControlNetForge Pro** is an industrial automation protocol engineering suite specifically targeted at **ControlNet (ODVA CIP / IEC 61158 Type 2)** networks. ControlNet is the deterministic, scheduled fieldbus standard developed by Rockwell Automation / Allen-Bradley that powered North American automotive body shops, continuous web processing, coordinated multi-axis motion, and heavy chemical batching.
This suite addresses key engineering hurdles:
1. **5.0 Mbps Manchester II Physical Layer Framing**: Assembles and validates physical coaxial bitstreams, 16-bit preambles (`0xAA55`), Start-of-Frame Sync Delimiters (`0x7E`), LNK headers, and ITU-T CRC-16 Frame Check Sequences ($x^{16} + x^{12} + x^5 + 1$).
2. **Network Update Time (NUT) & Scheduled Bandwidth Allocation**: Sequences CIP scheduled cyclic connections, calculates Scheduled Service Portion (SSP) and Unscheduled Service Portion (USP) intervals, and validates Requested Packet Interval (RPI) binary harmonization ($RPI = NUT \times 2^n$).
3. **SMax & UMax Boundary Verification**: Automates token rotation boundaries ($SMax \ge \text{highest scheduled node}$, $UMax \ge SMax$ and $\ge \text{highest network node}$) to eliminate token dropouts.
4. **RG-6 Coaxial Trunk & Tap Attenuation Sizer**: Models $75\ \Omega$ quad-shield coaxial cable attenuation ($1.63\text{ dB}/100\text{m}$ at $5.0\text{ MHz}$) and passive BNC tap insertion losses ($0.75\text{ dB/tap}$) against the strict $13.3\text{ dB}$ transceiver dynamic range limit.
5. **10-Point ControlNet Safety Auditor**: Pre-flight verification checking MAC ID ranges (`1..99`), duplicate node collision risks, 48-tap limits, dual $75\ \Omega$ terminators, SSP load ceilings ($\le 75\%$), and redundant media cabling.
6. **Multi-Target Exporter**: Outputs RSNetWorx for ControlNet schedule CSV tables, Studio 5000 / RSLogix 5000 tag alias mappings (`1756-CNBR` / `1756-CN2R`), and Python virtual frame generation scripts.

---

## 2. Standards & Physical Specifications
- **ODVA ControlNet Specification**: Volumes 1 & 4 (Common Industrial Protocol & ControlNet Adaptation).
- **IEC 61158-2 / IEC 61158-3 / IEC 61158-4**: Type 2 Fieldbus Specification.
- **Physical Signaling**: 5.0 Mbps Manchester II bi-phase encoding, carrier frequency 5.0 MHz.
- **Physical Media**: RG-6 Quad Shield $75\ \Omega$ coaxial cable, BNC connectors, passive taps (1786-TPR, 1786-TPS), $1.0\text{m}$ drop cables.
- **Termination**: Exactly two $75\ \Omega \pm 1\%$ metal film BNC terminators at trunk endpoints ($37.5\ \Omega$ net DC loop resistance).

---

## 3. Physical Frame Structure

```
+---------------+------+-------+---------+--------+------------------+--------+
| Preamble (2B) | Sync | MACID | Conn ID | Format | Data Payload (N) | CRC-16 |
+---------------+------+-------+---------+--------+------------------+--------+
     0xAA55       0x7E   1..99   16 bits    0x01      CIP I/O Bytes    2 bytes
```
- **Preamble**: `0xAA55` (16-bit Manchester clock synchronization pattern).
- **Sync Delimiter**: `0x7E` (HDLC-like synchronization flag).
- **MAC ID**: 1 byte node address (`1..99`).
- **Connection ID**: 2 bytes CIP Connection Identifier (`0x0001..0xFFFF`).
- **Format Field**: `0x01` Scheduled Data, `0x02` Unscheduled Data, `0x03` Token, `0x04` Beacon.
- **Payload**: Up to 500 bytes of process assembly data.
- **CRC-16**: Generator polynomial $x^{16} + x^{12} + x^5 + 1$ (`0x1021`), Initial value `0xFFFF`, Final XOR `0xFFFF`.

---

## 4. NUT Timing & Coaxial Loss Mathematical Models

### Network Update Time (NUT) Model
The total duration of a single NUT is:
$$T_{\text{NUT}} = T_{\text{SSP}} + T_{\text{USP}}$$

Where:
- $T_{\text{SSP}}$ (Scheduled Service Portion) $\le 75\% \times T_{\text{NUT}}$
- $T_{\text{USP}}$ (Unscheduled Service Portion) $\ge 25\% \times T_{\text{NUT}}$

For $N$ scheduled connections, each transmitting $B_i$ bytes at $5.0\text{ Mbps}$ ($0.2\ \mu\text{s/bit}$):
$$T_{\text{slot}, i} = 24.4\ \mu\text{s} + (B_i \times 8 \times 0.2\ \mu\text{s})$$
$$T_{\text{SSP}} = T_{\text{beacon}} + \sum_{i=1}^{N} T_{\text{slot}, i} + T_{\text{guardband}}$$
Where $T_{\text{beacon}} \approx 40\ \mu\text{s}$ and $T_{\text{guardband}} \approx 50\ \mu\text{s}$.

### Coaxial Signal Attenuation Model
$$A_{\text{total}} = \left( \frac{L_{\text{trunk}}}{100} \times 1.63\text{ dB} \right) + (N_{\text{taps}} \times 0.75\text{ dB}) \le 13.3\text{ dB}$$

Maximum allowable physical distance for a given tap count:
$$L_{\text{max}} = \frac{13.3 - (N_{\text{taps}} \times 0.75)}{0.0163}\text{ meters}$$

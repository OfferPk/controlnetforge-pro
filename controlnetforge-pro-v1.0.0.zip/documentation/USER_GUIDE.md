# ControlNetForge Pro - User Guide & Operator Manual

## 1. Quick Start
To launch the interactive web studio:
1. Open `product_199/source-code/index.html` in any modern web browser.
2. All calculations and protocol dissections execute client-side with zero external internet dependencies or complex installations.

To use the standalone Python CLI:
```bash
# Make CLI executable
chmod +x product_199/build/controlnet-cli.py

# Build a Scheduled I/O Data Frame for Node 2, Connection 0x1001
./product_199/build/controlnet-cli.py frame-build --mac 2 --conn 0x1001

# Dissect a raw ControlNet hex frame
./product_199/build/controlnet-cli.py frame-dissect "AA 55 7E 02 10 01 01 00 11 22 33 44 55 66 77 C1 76"

# Calculate NUT Bandwidth Allocation
./product_199/build/controlnet-cli.py nut-schedule --conns '[{"id":1,"bytes":32,"rpi":5.0},{"id":2,"bytes":64,"rpi":5.0}]' --nut 5.0

# Evaluate RG-6 Coaxial Line Attenuation
./product_199/build/controlnet-cli.py coax-size --trunk 400 --taps 4

# Run 10-Point Safety Auditor
./product_199/build/controlnet-cli.py audit --nodes '[{"mac":1},{"mac":2},{"mac":3}]' --conns '[{"id":1,"bytes":32,"rpi":5.0}]' --trunk 400 --taps 4
```

---

## 2. Workbench Tabs & Capabilities

### Tab 1: Scheduled Frame Studio & CRC
- Compose 5.0 Mbps Manchester II bi-phase scheduled frames with node MAC IDs (`1..99`), Connection IDs, and raw CIP payload bytes.
- Generates complete frames with 16-bit Preamble (`0xAA55`), Sync flag (`0x7E`), LNK header, and ITU-T CRC-16 FCS.
- Immediate field-by-field hex packet dissection and CRC verification.

### Tab 2: NUT Bandwidth & RPI Scheduler
- Add, edit, and configure CIP scheduled connections (producer/consumer MACs, RPIs in ms, and data byte lengths).
- Select NUT duration (2ms, 5ms, 10ms, 20ms) and configure SMax / UMax parameters.
- Visual readout of Scheduled Service Portion (SSP) versus Unscheduled Service Portion (USP), verifying SSP $\le 75\%$.

### Tab 3: RG-6 Coax & Tap Loss Sizer
- Enter total trunk length and count of installed BNC taps (1786-TPR/TPS).
- Calculates cable loss ($1.63\text{ dB}/100\text{m}$) and tap through-loss ($0.75\text{ dB/tap}$) against the $13.3\text{ dB}$ limit.
- Recommends when a 1786-RPA repeater module is required.

### Tab 4: 10-Point Safety Auditor
- Comprehensive pre-flight verification:
  - MAC ID 1..99 validation and duplicate address detection.
  - SMax and UMax parameter alignment.
  - 13.3 dB coaxial loss envelope and 48-tap segment limits.
  - Dual 75-ohm BNC line termination.
  - SSP scheduled load margin ($\le 75\%$).
  - Binary RPI multiplier harmonization ($RPI = NUT \times 2^n$).
  - Dual-cable redundant media and repeater hop limits.

### Tab 5: RSNetWorx / L5X Exporter
- Outputs RSNetWorx for ControlNet schedule CSV tables.
- Generates Studio 5000 / RSLogix 5000 tag alias blocks (`1756-CNBR` / `1756-CN2R`).
- Outputs Python 3 virtual scheduled frame simulation scripts.

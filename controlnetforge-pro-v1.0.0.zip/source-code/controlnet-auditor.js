/**
 * ControlNetForge Pro - 10-Point ControlNet Physical & Scheduled Protocol Safety Auditor
 * Enforces ODVA ControlNet Specification and Rockwell Automation (1786/1756) guidelines:
 * Node address range (1..99), duplicate MAC ID protection, SMax & UMax boundaries,
 * RG-6 attenuation limit (13.3 dB), max 48 taps/segment, dual 75-ohm BNC terminators,
 * NUT schedulability (SSP <= 75%), RPI binary harmonization, redundant media cabling,
 * and repeater hop latency margins.
 */

const ControlNetAuditor = (function () {
  const AUDIT_RULES = [
    {
      id: 'CNET-01',
      name: 'MAC ID Address Range Verification (1..99)',
      standard: 'ODVA ControlNet Spec Vol 1',
      severity: 'CRITICAL',
      description: 'Node MAC IDs must be valid integers between 1 and 99 (address 0 is strictly forbidden; 1 is typically Scanner).'
    },
    {
      id: 'CNET-02',
      name: 'Duplicate MAC ID Collision Guard',
      standard: 'ControlNet Medium Access Control',
      severity: 'CRITICAL',
      description: 'Duplicate MAC IDs cause simultaneous transceiver transmissions, high-frequency collisions, and severe token ring disruption.'
    },
    {
      id: 'CNET-03',
      name: 'SMax & UMax Parameter Alignment',
      standard: 'ODVA Network Configuration Spec',
      severity: 'ERROR',
      description: 'SMax must be >= highest scheduled node MAC ID. UMax must be >= SMax and >= highest unscheduled node address.'
    },
    {
      id: 'CNET-04',
      name: 'RG-6 Coaxial Maximum Signal Loss Envelope (13.3 dB)',
      standard: '1786-UM001 Physical Media Spec',
      severity: 'ERROR',
      description: 'Total segment attenuation (Cable loss at 1.63 dB/100m + Tap insertion loss at 0.75 dB/tap) must not exceed 13.3 dB without a repeater.'
    },
    {
      id: 'CNET-05',
      name: 'Maximum 48 Taps Per Coaxial Segment',
      standard: '1786-UM001 Table 2.1',
      severity: 'ERROR',
      description: 'No single physical coaxial segment may exceed 48 taps. Additional nodes require 1786-RPA repeater segmentation.'
    },
    {
      id: 'CNET-06',
      name: 'Dual 75-Ohm BNC Termination Resistors',
      standard: '1786-TPR/TPS Termination Spec',
      severity: 'CRITICAL',
      description: 'Exactly two 75 Ω 1% BNC terminators must be connected at the physical extreme endpoints of the coaxial trunk (37.5 Ω net DC load).'
    },
    {
      id: 'CNET-07',
      name: 'Scheduled Service Portion (SSP) Headroom (<= 75% NUT)',
      standard: 'ODVA CIP Scheduling Rules',
      severity: 'WARNING',
      description: 'Scheduled cyclic connections must not consume more than 75% of the NUT, preserving >= 25% for Unscheduled messaging (USP).'
    },
    {
      id: 'CNET-08',
      name: 'CIP Requested Packet Interval (RPI) Binary Multiplier Check',
      standard: '1756-CNBR / 1756-CN2R Guidelines',
      severity: 'WARNING',
      description: 'Connection RPIs must be exact binary multiples of NUT: RPI = NUT * 2^n (e.g. 5ms, 10ms, 20ms for a 5ms NUT).'
    },
    {
      id: 'CNET-09',
      name: 'Dual-Cable Redundant Media (Channel A & B) Validation',
      standard: 'Critical Process Redundancy Guidelines',
      severity: 'INFO',
      description: 'High-availability industrial lines should deploy dual coaxial channels (A and B) with matched trunk lengths to ensure seamless bumpless switchover.'
    },
    {
      id: 'CNET-10',
      name: 'Repeater Hop Delay & Network Propagation Budget',
      standard: 'ODVA Network Distance Timing',
      severity: 'WARNING',
      description: 'Maximum repeater count in series must not exceed 5 hops to maintain Manchester clock synchronization within NUT guardbands.'
    }
  ];

  /**
   * Run the 10-Point Safety Audit
   * @param {Object} config - {
   *   nodes: [ { macId, name, isScheduled } ],
   *   connections: [ { producerMac, consumerMac, rpiMs, dataBytes } ],
   *   nutMs: number,
   *   sMax: number,
   *   uMax: number,
   *   trunkLengthM: number,
   *   tapCount: number,
   *   terminatorsInstalled: number,
   *   isRedundantCabling: boolean,
   *   repeaterHops: number
   * }
   */
  function auditNetwork(config) {
    const nodes = config.nodes || [];
    const connections = config.connections || [];
    const nutMs = config.nutMs || 5.0;
    const sMax = config.sMax || 10;
    const uMax = config.uMax || 20;
    const trunkM = config.trunkLengthM || 400;
    const tapCount = config.tapCount || (nodes.length || 4);
    const terminators = config.terminatorsInstalled !== undefined ? config.terminatorsInstalled : 2;
    const isRedundant = config.isRedundantCabling === true;
    const repeaterHops = config.repeaterHops || 0;

    const findings = [];
    let passCount = 0;
    let warnCount = 0;
    let failCount = 0;

    // 1. MAC ID Address Range (1..99)
    const invalidMacs = nodes.filter(n => n.macId < 1 || n.macId > 99);
    if (invalidMacs.length > 0) {
      findings.push({
        id: 'CNET-01',
        status: 'FAIL',
        severity: 'CRITICAL',
        details: `Invalid MAC IDs detected: ${invalidMacs.map(n => n.macId).join(', ')}. ControlNet valid range is 1..99 (Node 0 is prohibited).`
      });
      failCount++;
    } else {
      findings.push({
        id: 'CNET-01',
        status: 'PASS',
        severity: 'INFO',
        details: 'All node MAC IDs are within legitimate 1..99 address space.'
      });
      passCount++;
    }

    // 2. Duplicate MAC ID Collision Guard
    const macs = nodes.map(n => n.macId);
    const dups = [...new Set(macs.filter((m, i) => macs.indexOf(m) !== i))];
    if (dups.length > 0) {
      findings.push({
        id: 'CNET-02',
        status: 'FAIL',
        severity: 'CRITICAL',
        details: `Duplicate MAC ID detected: Node(s) ${dups.join(', ')}. Causes simultaneous RF collisions and immediate token halt.`
      });
      failCount++;
    } else {
      findings.push({
        id: 'CNET-02',
        status: 'PASS',
        severity: 'INFO',
        details: 'Zero MAC ID collisions detected. Unique token addressing verified.'
      });
      passCount++;
    }

    // 3. SMax & UMax Parameter Alignment
    const highestScheduledMac = Math.max(...nodes.filter(n => n.isScheduled !== false).map(n => n.macId), 1);
    const highestMac = Math.max(...macs, 1);
    let smaxUmaxFail = false;
    let smaxUmaxDetails = [];

    if (sMax < highestScheduledMac) {
      smaxUmaxFail = true;
      smaxUmaxDetails.push(`SMax (${sMax}) is lower than highest scheduled node (${highestScheduledMac}). Node will be excluded from cyclic schedule.`);
    }
    if (uMax < sMax) {
      smaxUmaxFail = true;
      smaxUmaxDetails.push(`UMax (${uMax}) is lower than SMax (${sMax}). Invalid token rotation boundary.`);
    }
    if (uMax < highestMac) {
      smaxUmaxFail = true;
      smaxUmaxDetails.push(`UMax (${uMax}) is lower than highest network node (${highestMac}). Node will never receive unscheduled token.`);
    }

    if (smaxUmaxFail) {
      findings.push({
        id: 'CNET-03',
        status: 'FAIL',
        severity: 'ERROR',
        details: smaxUmaxDetails.join(' ')
      });
      failCount++;
    } else {
      findings.push({
        id: 'CNET-03',
        status: 'PASS',
        severity: 'INFO',
        details: `SMax (${sMax}) and UMax (${uMax}) are correctly aligned with network topology (Highest Node: ${highestMac}).`
      });
      passCount++;
    }

    // 4. RG-6 Coaxial Maximum Signal Loss Envelope (13.3 dB)
    const cableLossDb = (trunkM / 100.0) * 1.63;
    const tapLossDb = tapCount * 0.75;
    const totalLossDb = parseFloat((cableLossDb + tapLossDb).toFixed(2));
    if (totalLossDb > 13.3) {
      findings.push({
        id: 'CNET-04',
        status: 'FAIL',
        severity: 'ERROR',
        details: `Total segment loss (${totalLossDb} dB = ${cableLossDb.toFixed(1)}dB cable + ${tapLossDb.toFixed(1)}dB taps) exceeds 13.3 dB transceiver limit. Repeater (1786-RPA) required.`
      });
      failCount++;
    } else {
      findings.push({
        id: 'CNET-04',
        status: 'PASS',
        severity: 'INFO',
        details: `Segment loss (${totalLossDb} dB) complies with 13.3 dB maximum dynamic range (Safety Margin: ${(13.3 - totalLossDb).toFixed(1)} dB).`
      });
      passCount++;
    }

    // 5. Maximum 48 Taps Per Coaxial Segment
    if (tapCount > 48) {
      findings.push({
        id: 'CNET-05',
        status: 'FAIL',
        severity: 'ERROR',
        details: `Installed tap count (${tapCount}) exceeds 48-tap physical limit per coaxial segment.`
      });
      failCount++;
    } else {
      findings.push({
        id: 'CNET-05',
        status: 'PASS',
        severity: 'INFO',
        details: `Tap count (${tapCount}/48) within allowable transceiver load envelope.`
      });
      passCount++;
    }

    // 6. Dual 75-Ohm BNC Termination Resistors
    if (terminators !== 2) {
      findings.push({
        id: 'CNET-06',
        status: 'FAIL',
        severity: 'CRITICAL',
        details: `Termination fault: ${terminators} terminators detected. Exactly two 75-ohm 1% BNC terminators required at trunk endpoints.`
      });
      failCount++;
    } else {
      findings.push({
        id: 'CNET-06',
        status: 'PASS',
        severity: 'INFO',
        details: 'Dual 75-ohm 1% BNC terminators confirmed (37.5-ohm equivalent DC loop resistance).'
      });
      passCount++;
    }

    // 7. Scheduled Service Portion (SSP) Headroom (<= 75% NUT)
    // Approximate schedule time: 40us beacon + per connection (24.4us + bytes*1.6us) + 50us guard
    let schedUs = 40.0 + 50.0;
    connections.forEach(c => {
      schedUs += 24.4 + ((c.dataBytes || 16) * 8 * 0.2);
    });
    const nutUs = nutMs * 1000.0;
    const schedLoad = (schedUs / nutUs) * 100.0;
    if (schedLoad > 75.0) {
      findings.push({
        id: 'CNET-07',
        status: 'WARN',
        severity: 'WARNING',
        details: `Scheduled bandwidth consumes ${schedLoad.toFixed(1)}% of NUT (> 75% threshold). Insufficient unscheduled time for messaging and HMI.`
      });
      warnCount++;
    } else {
      findings.push({
        id: 'CNET-07',
        status: 'PASS',
        severity: 'INFO',
        details: `Scheduled bandwidth load is ${schedLoad.toFixed(1)}% (<= 75% NUT limit, preserving ${(100.0 - schedLoad).toFixed(1)}% for unscheduled traffic).`
      });
      passCount++;
    }

    // 8. RPI Binary Multiplier Check (RPI = NUT * 2^n)
    const nonBinaryRpis = connections.filter(c => {
      const ratio = c.rpiMs / nutMs;
      return ratio < 1 || (Math.log2(ratio) % 1 !== 0);
    });
    if (nonBinaryRpis.length > 0) {
      findings.push({
        id: 'CNET-08',
        status: 'WARN',
        severity: 'WARNING',
        details: `Non-binary RPI multipliers detected on connections: ${nonBinaryRpis.map(c => `${c.name || 'Conn'} (${c.rpiMs}ms vs NUT ${nutMs}ms)`).join(', ')}. Must equal NUT * 2^n.`
      });
      warnCount++;
    } else {
      findings.push({
        id: 'CNET-08',
        status: 'PASS',
        severity: 'INFO',
        details: 'All connection RPI values are harmonious binary multiples of NUT (RPI = NUT * 2^n).'
      });
      passCount++;
    }

    // 9. Dual-Cable Redundant Media Validation
    if (!isRedundant) {
      findings.push({
        id: 'CNET-09',
        status: 'WARN',
        severity: 'INFO',
        details: 'Single coaxial media configured (Channel A only). Cable cut will isolate all downstream stations.'
      });
      warnCount++;
    } else {
      findings.push({
        id: 'CNET-09',
        status: 'PASS',
        severity: 'INFO',
        details: 'Dual-cable redundant media active (Channel A + B) with automatic hardware failover.'
      });
      passCount++;
    }

    // 10. Repeater Hop Delay
    if (repeaterHops > 5) {
      findings.push({
        id: 'CNET-10',
        status: 'WARN',
        severity: 'WARNING',
        details: `Repeater hop count (${repeaterHops}) exceeds 5-hop synchronization limit.`
      });
      warnCount++;
    } else {
      findings.push({
        id: 'CNET-10',
        status: 'PASS',
        severity: 'INFO',
        details: `Repeater topology is compliant (${repeaterHops}/5 hops).`
      });
      passCount++;
    }

    const overallScore = Math.max(0, 100 - (failCount * 25) - (warnCount * 10));
    const grade = overallScore >= 90 ? 'A (CONTROLNET ODVA CERTIFIED)' : (overallScore >= 75 ? 'B (COMPLIANT WITH WARNINGS)' : 'C (ACTION REQUIRED)');

    return {
      rules: AUDIT_RULES,
      findings,
      summary: {
        totalRules: AUDIT_RULES.length,
        passCount,
        warnCount,
        failCount,
        overallScore,
        grade
      }
    };
  }

  return {
    AUDIT_RULES,
    auditNetwork
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = ControlNetAuditor;
}

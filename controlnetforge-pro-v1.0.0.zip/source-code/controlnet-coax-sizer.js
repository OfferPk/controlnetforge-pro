/**
 * ControlNetForge Pro - RG-6 Coaxial Trunk & Tap Attenuation Sizer
 * Models 75-ohm coaxial cable attenuation at 5.0 MHz (1.63 dB/100m),
 * BNC drop tap insertion losses (0.75 dB/tap), repeater segmentation boundaries,
 * and maximum segment attenuation envelope (13.3 dB max dynamic range).
 */

const ControlNetCoaxSizer = (function () {
  const RG6_SPECS = {
    standard: 'RG-6 Quad Shield 75-Ohm Coax',
    carrierFrequencyMhz: 5.0,
    cableLossDbPer100m: 1.63,     // 1.63 dB per 100 meters at 5 MHz
    tapInsertionLossDb: 0.75,     // 0.75 dB through-loss per passive BNC tap
    maxAllowedLossDb: 13.3,       // Max permissible signal attenuation between any two transceivers
    maxTapsPerSegment: 48,        // Max physical taps on one coaxial segment without repeater
    maxSegmentDistanceMeters: 1000,// Absolute maximum physical segment distance (at minimum tap count)
    terminatorResistanceOhms: 75.0,// 75 Ω +/- 1% metal film terminator
    dropCableLengthMeters: 1.0    // Fixed 1.0m flexible BNC drop cable included with tap
  };

  /**
   * Calculates Maximum Permissible Segment Distance based on Tap Count
   * Formula:
   * Total Loss = (Distance / 100 * 1.63) + (TapCount * 0.75) <= 13.3 dB
   * Distance <= (13.3 - (TapCount * 0.75)) / (1.63 / 100)
   */
  function calculateMaxDistanceForTaps(tapCount) {
    const taps = Math.min(RG6_SPECS.maxTapsPerSegment, Math.max(2, tapCount));
    const tapLossTotal = taps * RG6_SPECS.tapInsertionLossDb;
    const availableCableLossDb = Math.max(0, RG6_SPECS.maxAllowedLossDb - tapLossTotal);
    const maxDistanceM = Math.min(RG6_SPECS.maxSegmentDistanceMeters, Math.floor((availableCableLossDb / RG6_SPECS.cableLossDbPer100m) * 100.0));

    return {
      taps,
      tapLossTotalDb: parseFloat(tapLossTotal.toFixed(2)),
      availableCableLossDb: parseFloat(availableCableLossDb.toFixed(2)),
      maxPermissibleDistanceM: Math.max(0, maxDistanceM)
    };
  }

  /**
   * Evaluates a physical coaxial segment's attenuation and signal integrity
   * @param {number} totalTrunkLengthMeters - Total RG-6 coaxial cable length
   * @param {number} installedTapCount - Number of connected 1786-TPR/TPS taps
   * @param {number} terminatorsInstalled - Should be exactly 2
   */
  function evaluateCoaxSegment(totalTrunkLengthMeters, installedTapCount, terminatorsInstalled = 2) {
    const cableLossDb = parseFloat(((totalTrunkLengthMeters / 100.0) * RG6_SPECS.cableLossDbPer100m).toFixed(2));
    const tapLossDb = parseFloat((installedTapCount * RG6_SPECS.tapInsertionLossDb).toFixed(2));
    const totalAttenuationDb = parseFloat((cableLossDb + tapLossDb).toFixed(2));
    const lossMarginDb = parseFloat((RG6_SPECS.maxAllowedLossDb - totalAttenuationDb).toFixed(2));

    const maxAllowableDistanceM = calculateMaxDistanceForTaps(installedTapCount).maxPermissibleDistanceM;

    // Propagation Delay (Velocity factor 0.82 -> 4.07 ns/m)
    const propagationDelayUs = parseFloat(((totalTrunkLengthMeters * 4.07) / 1000.0).toFixed(3));

    return {
      trunkLengthMeters: totalTrunkLengthMeters,
      installedTapCount,
      terminatorsInstalled,
      cableLossDb,
      tapLossDb,
      totalAttenuationDb,
      lossMarginDb,
      maxAllowedLossDb: RG6_SPECS.maxAllowedLossDb,
      maxAllowableDistanceM,
      propagationDelayUs,
      isAttenuationCompliant: totalAttenuationDb <= RG6_SPECS.maxAllowedLossDb,
      isTapCountCompliant: installedTapCount <= RG6_SPECS.maxTapsPerSegment,
      isTerminationCompliant: terminatorsInstalled === 2,
      recommendation: totalAttenuationDb > RG6_SPECS.maxAllowedLossDb ? 'REPEATER_REQUIRED (1786-RPA/RPFM)' : 'MARGIN_SAFE'
    };
  }

  return {
    RG6_SPECS,
    calculateMaxDistanceForTaps,
    evaluateCoaxSegment
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = ControlNetCoaxSizer;
}

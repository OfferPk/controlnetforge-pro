/**
 * ControlNetForge Pro - Network Update Time (NUT) & Scheduled Bandwidth Allocator
 * Calculates deterministic NUT boundaries (2ms..100ms), Scheduled Service Portion (SSP),
 * Unscheduled Service Portion (USP), SMax (maximum scheduled node), UMax (maximum unscheduled node),
 * Guardband time allocations, and CIP Requested Packet Interval (RPI) harmonizations.
 */

const ControlNetNutScheduler = (function () {
  /**
   * Generates a deterministic NUT schedule for a list of scheduled I/O connections.
   * @param {Array} connections - List of CIP scheduled connections:
   *   [
   *     { id: 1, name: 'Flex I/O Rack 1', producerMac: 2, consumerMac: 1, rpiMs: 5.0, dataBytes: 32 },
   *     { id: 2, name: 'Kinetix 6000 Drive 1', producerMac: 3, consumerMac: 1, rpiMs: 5.0, dataBytes: 64 },
   *     { id: 3, name: 'PowerFlex 700 VFD', producerMac: 4, consumerMac: 1, rpiMs: 10.0, dataBytes: 16 }
   *   ]
   * @param {number} nutMs - Network Update Time in milliseconds (2, 5, 10, 20 ms)
   * @param {number} sMax - Maximum Scheduled MAC ID address (1..99)
   * @param {number} uMax - Maximum Unscheduled MAC ID address (sMax..99)
   */
  function calculateNutSchedule(connections, nutMs = 5.0, sMax = 10, uMax = 20) {
    const nutUs = nutMs * 1000.0;
    const bitRateMbps = 5.0; // 5.0 Mbps Manchester II
    const bitTimeUs = 1.0 / bitRateMbps; // 0.2 µs per bit

    // Moderator beacon + Start-of-NUT synchronization = ~40 µs
    const nutPreambleSyncUs = 40.0;

    // Slot overhead per scheduled node transmission (preamble, sync, LNK header, CRC, inter-slot gap)
    // 2B Preamble + 1B Sync + 1B MAC + 2B Conn + 1B Format + 2B CRC = 9B fixed header = 72 bits = 14.4 µs
    // Inter-slot turnaround silence gap = ~10 µs
    const slotFixedOverheadUs = 24.4;

    let totalScheduledPayloadBits = 0;
    let scheduledSlotTimeUs = 0;

    const connectionTimings = connections.map(conn => {
      const payloadBytes = Math.min(500, Math.max(1, conn.dataBytes || 8));
      const payloadBits = payloadBytes * 8;
      const payloadDurationUs = payloadBits * bitTimeUs;
      const fullTransactionUs = slotFixedOverheadUs + payloadDurationUs;

      totalScheduledPayloadBits += payloadBits;
      scheduledSlotTimeUs += fullTransactionUs;

      // Validate RPI harmonization: RPI must equal NUT * 2^n
      const rpiRatio = conn.rpiMs / nutMs;
      const isPowerOfTwo = (rpiRatio >= 1) && (Math.log2(rpiRatio) % 1 === 0);
      const recommendedRpiMs = isPowerOfTwo ? conn.rpiMs : (Math.pow(2, Math.ceil(Math.log2(Math.max(1, rpiRatio)))) * nutMs);

      return {
        id: conn.id,
        name: conn.name || `Connection ${conn.id}`,
        producerMac: conn.producerMac,
        consumerMac: conn.consumerMac,
        rpiMs: conn.rpiMs,
        isRpiHarmonized: isPowerOfTwo,
        recommendedRpiMs,
        dataBytes: payloadBytes,
        durationUs: Math.round(fullTransactionUs)
      };
    });

    // Guardband time between Scheduled and Unscheduled portion (~50 µs)
    const guardbandUs = 50.0;
    const totalScheduledServicePortionUs = nutPreambleSyncUs + scheduledSlotTimeUs + guardbandUs;
    const totalScheduledServicePortionMs = parseFloat((totalScheduledServicePortionUs / 1000.0).toFixed(3));

    // Remaining time in NUT is strictly reserved for Unscheduled Service Portion (USP)
    const unscheduledServicePortionUs = Math.max(0, nutUs - totalScheduledServicePortionUs);
    const unscheduledServicePortionMs = parseFloat((unscheduledServicePortionUs / 1000.0).toFixed(3));

    const scheduledLoadPercent = parseFloat(((totalScheduledServicePortionUs / nutUs) * 100.0).toFixed(1));
    const unscheduledHeadroomPercent = parseFloat(((unscheduledServicePortionUs / nutUs) * 100.0).toFixed(1));

    // Verify SMax / UMax bounds
    const maxConfiguredMac = Math.max(...connections.map(c => Math.max(c.producerMac, c.consumerMac)), 1);
    const isSMaxValid = sMax >= maxConfiguredMac;
    const isUMaxValid = uMax >= sMax;

    return {
      nutMs,
      nutUs,
      sMax,
      uMax,
      maxConfiguredMac,
      isSMaxValid,
      isUMaxValid,
      connectionTimings,
      totalScheduledServicePortionMs,
      totalScheduledServicePortionUs: Math.round(totalScheduledServicePortionUs),
      unscheduledServicePortionMs,
      unscheduledServicePortionUs: Math.round(unscheduledServicePortionUs),
      scheduledLoadPercent,
      unscheduledHeadroomPercent,
      isSchedulable: totalScheduledServicePortionUs <= (nutUs * 0.75), // Max 75% scheduled capacity per ODVA
      status: totalScheduledServicePortionUs <= (nutUs * 0.75) ? 'SCHEDULED_OPTIMAL' : (totalScheduledServicePortionUs <= nutUs ? 'HIGH_SCHEDULED_LOAD' : 'NUT_OVERRUN')
    };
  }

  return {
    calculateNutSchedule
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = ControlNetNutScheduler;
}

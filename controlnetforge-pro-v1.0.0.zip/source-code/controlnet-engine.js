/**
 * ControlNetForge Pro - ControlNet Physical Layer & Scheduled Frame Engine
 * Implements 5.0 Mbps Manchester II bi-phase signaling framing, Preamble/Sync words,
 * LNK (Link layer) headers, CIP Scheduled I/O Connection PDU packing,
 * Unscheduled Explicit Message Framing, and ITU-T CRC-16 Frame Check Sequences.
 */

const ControlNetEngine = (function () {
  // Preamble & Delimiter Patterns
  const PREAMBLE_WORD = 0xAA55;  // 16-bit Manchester Clock Synchronization
  const SYNC_DELIMITER = 0x7E;   // Start of Frame Delimiter (HDLC-like flag)

  // ControlNet Frame Types (Format Field in Link Layer Header)
  const FRAME_TYPES = {
    0x01: { name: 'SCHEDULED_DATA', desc: 'Scheduled deterministic cyclic I/O connection payload' },
    0x02: { name: 'UNSCHEDULED_DATA', desc: 'Unscheduled acyclic explicit messaging / UCMM payload' },
    0x03: { name: 'MODERATOR_TOKEN', desc: 'Moderator / Token rotation maintenance frame' },
    0x04: { name: 'BEACON', desc: 'NUT start-of-interval synchronization beacon' },
    0x05: { name: 'BUS_IDLE', desc: 'Inter-slot idle line silence' }
  };

  // Common Scheduled Transmission Intervals (RPI in milliseconds)
  // Allowed RPI values must be binary multiples of NUT: NUT * 2^n
  const VALID_RPI_MULTIPLIERS = [1, 2, 4, 8, 16, 32, 64, 128];

  // Standard RG-6 Coaxial Cable Physical Properties
  const COAX_SPECS = {
    cableType: 'RG-6 Quad Shield 75-Ohm High-Flex Coaxial',
    impedanceOhms: 75.0,
    velocityOfPropagation: 0.82, // 82% of c -> ~4.07 ns/meter
    tapAttenuationDb: 0.75,      // Nominal tap insertion loss at 5 MHz
    cableAttenuationDbPer100m: 1.63, // at 5 MHz
    maxAllowedSegmentLossDb: 13.3,   // Maximum transceiver dynamic range loss
    terminatorResistanceOhms: 75.0,
    terminatorTolerancePercent: 1.0,
    dropCableLengthM: 1.0        // Fixed 1.0m tap drop cable to BNC transceiver
  };

  /**
   * Calculates ITU-T CRC-16 (Polynomial: x^16 + x^12 + x^5 + 1 -> 0x1021)
   * Initial value 0xFFFF, Final XOR 0xFFFF
   */
  function calculateControlNetCrc16(dataBytes) {
    let crc = 0xFFFF;
    for (const b of dataBytes) {
      crc ^= (b << 8);
      for (let i = 0; i < 8; i++) {
        if (crc & 0x8000) {
          crc = ((crc << 1) ^ 0x1021) & 0xFFFF;
        } else {
          crc = (crc << 1) & 0xFFFF;
        }
      }
    }
    return crc ^ 0xFFFF;
  }

  /**
   * Builds a ControlNet Scheduled I/O Data Frame
   * Format:
   * [Preamble 2B] + [Sync 1B] + [MacID 1B] + [ConnID 2B] + [Format 1B] + [Payload N Bytes] + [FCS 2B]
   */
  function buildScheduledFrame(options) {
    const opts = Object.assign({
      macId: 1,           // Node address 1..99
      connectionId: 0x1001,// 16-bit CIP Originator/Target Connection ID
      payload: [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07] // 8 bytes sample I/O data
    }, options);

    if (opts.macId < 1 || opts.macId > 99) {
      throw new Error(`Invalid MAC ID ${opts.macId}. ControlNet valid range is 1..99.`);
    }

    const formatByte = 0x01; // SCHEDULED_DATA
    const connBytes = [(opts.connectionId >> 8) & 0xFF, opts.connectionId & 0xFF];
    const coreData = [opts.macId & 0xFF, ...connBytes, formatByte, ...(opts.payload || [])];

    const crc = calculateControlNetCrc16(coreData);
    const crcBytes = [(crc >> 8) & 0xFF, crc & 0xFF];

    const fullFrame = [
      (PREAMBLE_WORD >> 8) & 0xFF, PREAMBLE_WORD & 0xFF,
      SYNC_DELIMITER,
      ...coreData,
      ...crcBytes
    ];

    const hexString = fullFrame.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ');

    // At 5.0 Mbps, each bit is 200 ns (0.2 µs)
    const totalBits = fullFrame.length * 8;
    const durationUs = parseFloat((totalBits * 0.2).toFixed(2));

    return {
      frameType: 'SCHEDULED_DATA',
      macId: opts.macId,
      connectionIdHex: `0x${opts.connectionId.toString(16).padStart(4, '0').toUpperCase()}`,
      payloadBytesCount: (opts.payload || []).length,
      bytes: fullFrame,
      hexString,
      crcHex: `0x${crc.toString(16).padStart(4, '0').toUpperCase()}`,
      totalBytes: fullFrame.length,
      durationUs,
      desc: `Scheduled cyclic frame from Node ${opts.macId} (Connection 0x${opts.connectionId.toString(16).padStart(4, '0').toUpperCase()})`
    };
  }

  /**
   * Dissects an incoming ControlNet Hex String
   */
  function dissectFrame(hexStr) {
    const cleanHex = hexStr.replace(/[^0-9a-fA-F]/g, '');
    const bytes = [];
    for (let i = 0; i < cleanHex.length; i += 2) {
      bytes.push(parseInt(cleanHex.substr(i, 2), 16));
    }

    if (bytes.length < 8) {
      throw new Error(`Frame too short (${bytes.length} bytes, minimum 8 required for ControlNet LNK header)`);
    }

    const syncIdx = bytes.indexOf(SYNC_DELIMITER);
    if (syncIdx === -1 || bytes.length < syncIdx + 6) {
      throw new Error("Missing SYNC delimiter (0x7E) or truncated frame header.");
    }

    const coreData = bytes.slice(syncIdx + 1, bytes.length - 2);
    const receivedCrc = (bytes[bytes.length - 2] << 8) | bytes[bytes.length - 1];
    const computedCrc = calculateControlNetCrc16(coreData);
    const isCrcValid = (receivedCrc === computedCrc);

    const macId = coreData[0];
    const connId = (coreData[1] << 8) | coreData[2];
    const format = coreData[3];
    const payload = coreData.slice(4);

    const typeMeta = FRAME_TYPES[format] || { name: 'UNKNOWN', desc: '' };

    return {
      macId,
      connectionIdHex: `0x${connId.toString(16).padStart(4, '0').toUpperCase()}`,
      formatByte: `0x${format.toString(16).padStart(2, '0').toUpperCase()}`,
      formatName: typeMeta.name,
      formatDesc: typeMeta.desc,
      payloadBytes: payload,
      payloadHex: payload.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' '),
      receivedCrc: `0x${receivedCrc.toString(16).padStart(4, '0').toUpperCase()}`,
      computedCrc: `0x${computedCrc.toString(16).padStart(4, '0').toUpperCase()}`,
      isCrcValid,
      totalBytes: bytes.length
    };
  }

  return {
    PREAMBLE_WORD,
    SYNC_DELIMITER,
    FRAME_TYPES,
    VALID_RPI_MULTIPLIERS,
    COAX_SPECS,
    calculateControlNetCrc16,
    buildScheduledFrame,
    dissectFrame
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = ControlNetEngine;
}

/**
 * ControlNetForge Pro - Web Application Controller
 */

document.addEventListener('DOMContentLoaded', function () {
  // Navigation Tabs
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));

      btn.classList.add('active');
      const targetId = btn.getAttribute('data-tab');
      document.getElementById(targetId).classList.add('active');
    });
  });

  // Default Datasets
  let connections = [
    { id: 1, name: '1794-ACNR Flex I/O Drop 1', producerMac: 2, consumerMac: 1, rpiMs: 5.0, dataBytes: 32 },
    { id: 2, name: '1794-ACNR Flex I/O Drop 2', producerMac: 3, consumerMac: 1, rpiMs: 5.0, dataBytes: 32 },
    { id: 3, name: 'Kinetix 6000 Servo Axis 1', producerMac: 4, consumerMac: 1, rpiMs: 5.0, dataBytes: 64 },
    { id: 4, name: 'PowerFlex 700 VFD Feed Motor', producerMac: 5, consumerMac: 1, rpiMs: 10.0, dataBytes: 16 }
  ];

  let nodes = [
    { macId: 1, name: 'ControlLogix 1756-CN2R Scanner', isScheduled: true },
    { macId: 2, name: 'Flex I/O Drop 1', isScheduled: true },
    { macId: 3, name: 'Flex I/O Drop 2', isScheduled: true },
    { macId: 4, name: 'Kinetix 6000 Servo Axis 1', isScheduled: true },
    { macId: 5, name: 'PowerFlex 700 VFD', isScheduled: true },
    { macId: 10, name: 'PanelView Plus HMI (Unscheduled)', isScheduled: false }
  ];

  // TAB 1: Scheduled Frame Builder
  function renderFrame() {
    const macId = parseInt(document.getElementById('frame-mac').value) || 1;
    const connStr = document.getElementById('frame-conn-id').value;
    const connId = connStr.startsWith('0x') || connStr.startsWith('0X') ? parseInt(connStr, 16) : parseInt(connStr, 10);
    const payloadStr = document.getElementById('frame-payload').value;
    const payloadBytes = payloadStr.split(',').map(s => {
      const t = s.trim();
      return t.startsWith('0x') || t.startsWith('0X') ? parseInt(t, 16) : parseInt(t, 10);
    }).filter(n => !isNaN(n));

    const frameRes = ControlNetEngine.buildScheduledFrame({
      macId,
      connectionId: connId,
      payload: payloadBytes
    });

    document.getElementById('frame-hex-output').innerText = frameRes.hexString;
    document.getElementById('frame-byte-badge').innerText = `${frameRes.totalBytes} Bytes (${frameRes.durationUs} µs @ 5M)`;

    const tbody = document.getElementById('dissect-tbody');
    tbody.innerHTML = `
      <tr><td>Preamble &amp; Sync</td><td>0xAA55 0x7E</td><td>Manchester II Synchronization + HDLC Sync Flag</td></tr>
      <tr><td>Node MAC ID</td><td>${frameRes.macId} (0x${frameRes.macId.toString(16).padStart(2, '0').toUpperCase()})</td><td>Producing Station Address</td></tr>
      <tr><td>Connection ID</td><td>${frameRes.connectionIdHex}</td><td>CIP Scheduled Connection Identifier</td></tr>
      <tr><td>Format Field</td><td>0x01</td><td>SCHEDULED_DATA</td></tr>
      <tr><td>Payload Bytes</td><td>${payloadBytes.length} Bytes</td><td>${payloadBytes.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ')}</td></tr>
      <tr><td>CRC-16 FCS</td><td>${frameRes.crcHex}</td><td>ITU-T CRC-16 Valid</td></tr>
    `;
  }

  document.getElementById('btn-build-frame').addEventListener('click', renderFrame);

  // TAB 2: NUT Scheduler
  function renderConnsTable() {
    const tbody = document.getElementById('tbody-conns');
    tbody.innerHTML = '';

    connections.forEach((c, idx) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><input type="text" class="form-control" value="${c.name}" onchange="updateConn(${idx}, 'name', this.value)"></td>
        <td><input type="number" class="form-control" style="width: 70px;" value="${c.producerMac}" onchange="updateConn(${idx}, 'producerMac', this.value)"></td>
        <td><input type="number" class="form-control" style="width: 70px;" value="${c.consumerMac}" onchange="updateConn(${idx}, 'consumerMac', this.value)"></td>
        <td><input type="number" step="0.5" class="form-control" style="width: 80px;" value="${c.rpiMs}" onchange="updateConn(${idx}, 'rpiMs', this.value)"></td>
        <td><input type="number" class="form-control" style="width: 80px;" value="${c.dataBytes}" onchange="updateConn(${idx}, 'dataBytes', this.value)"></td>
        <td><button class="btn btn-secondary" style="padding: 4px 8px; color: var(--red-accent);" onclick="removeConn(${idx})">✕</button></td>
      `;
      tbody.appendChild(tr);
    });

    recalculateNut();
  }

  window.updateConn = function (idx, field, val) {
    if (field === 'name') {
      connections[idx][field] = val;
    } else if (field === 'rpiMs') {
      connections[idx][field] = parseFloat(val) || 5.0;
    } else {
      connections[idx][field] = parseInt(val) || 1;
    }
    recalculateNut();
  };

  window.removeConn = function (idx) {
    if (connections.length > 1) {
      connections.splice(idx, 1);
      renderConnsTable();
    }
  };

  document.getElementById('btn-add-conn').addEventListener('click', () => {
    const nextId = connections.length + 1;
    connections.push({
      id: nextId,
      name: `Scheduled Connection ${nextId}`,
      producerMac: nextId + 1,
      consumerMac: 1,
      rpiMs: 5.0,
      dataBytes: 32
    });
    renderConnsTable();
  });

  function recalculateNut() {
    const nutMs = parseFloat(document.getElementById('nut-select').value) || 5.0;
    const sMax = parseInt(document.getElementById('smax-input').value) || 10;
    const uMax = parseInt(document.getElementById('umax-input').value) || 20;

    const res = ControlNetNutScheduler.calculateNutSchedule(connections, nutMs, sMax, uMax);

    document.getElementById('stat-nut-val').innerText = `${res.nutMs.toFixed(1)} ms`;
    document.getElementById('stat-ssp-load').innerText = `${res.scheduledLoadPercent}%`;
    document.getElementById('stat-usp-headroom').innerText = `${res.unscheduledHeadroomPercent}%`;

    if (res.isSchedulable) {
      document.getElementById('stat-ssp-load').style.color = '#f87171';
      document.getElementById('stat-usp-headroom').style.color = 'var(--emerald-accent)';
    } else {
      document.getElementById('stat-ssp-load').style.color = 'var(--red-accent)';
      document.getElementById('stat-usp-headroom').style.color = 'var(--red-accent)';
    }

    recalculateCoax();
  }

  document.getElementById('btn-recalc-nut').addEventListener('click', recalculateNut);
  document.getElementById('nut-select').addEventListener('change', recalculateNut);

  // TAB 3: Coax Sizer
  function recalculateCoax() {
    const trunkM = parseInt(document.getElementById('coax-trunk-len').value) || 400;
    const tapCount = parseInt(document.getElementById('coax-tap-count').value) || 4;
    const terms = parseInt(document.getElementById('coax-terminators').value) || 2;

    const res = ControlNetCoaxSizer.evaluateCoaxSegment(trunkM, tapCount, terms);

    document.getElementById('stat-coax-loss').innerText = `${res.totalAttenuationDb} dB`;
    document.getElementById('stat-coax-margin').innerText = `${res.lossMarginDb} dB`;
    document.getElementById('stat-coax-max-dist').innerText = `${res.maxAllowableDistanceM} m`;

    if (res.isAttenuationCompliant) {
      document.getElementById('stat-coax-loss').style.color = '#f87171';
      document.getElementById('stat-coax-margin').style.color = 'var(--emerald-accent)';
    } else {
      document.getElementById('stat-coax-loss').style.color = 'var(--red-accent)';
      document.getElementById('stat-coax-margin').style.color = 'var(--red-accent)';
    }
  }

  document.getElementById('btn-recalc-coax').addEventListener('click', recalculateCoax);

  // TAB 4: Safety Auditor
  function runAudit() {
    const nutMs = parseFloat(document.getElementById('nut-select').value) || 5.0;
    const sMax = parseInt(document.getElementById('smax-input').value) || 10;
    const uMax = parseInt(document.getElementById('umax-input').value) || 20;
    const trunkM = parseInt(document.getElementById('coax-trunk-len').value) || 400;
    const tapCount = parseInt(document.getElementById('coax-tap-count').value) || 4;
    const terms = parseInt(document.getElementById('coax-terminators').value) || 2;

    const auditRes = ControlNetAuditor.auditNetwork({
      nodes,
      connections,
      nutMs,
      sMax,
      uMax,
      trunkLengthM: trunkM,
      tapCount,
      terminatorsInstalled: terms,
      isRedundantCabling: true,
      repeaterHops: 0
    });

    document.getElementById('audit-score').innerText = `${auditRes.summary.overallScore}/100`;
    document.getElementById('audit-grade').innerText = auditRes.summary.grade;
    document.getElementById('audit-summary-counts').innerText =
      `${auditRes.summary.passCount} Pass / ${auditRes.summary.warnCount} Warn / ${auditRes.summary.failCount} Fail`;

    const container = document.getElementById('audit-results-container');
    container.innerHTML = '';

    auditRes.findings.forEach(f => {
      const rule = auditRes.rules.find(r => r.id === f.id);
      const item = document.createElement('div');
      item.className = 'audit-item';

      let statusClass = 'audit-pass';
      if (f.status === 'WARN') statusClass = 'audit-warn';
      if (f.status === 'FAIL') statusClass = 'audit-fail';

      item.innerHTML = `
        <span class="audit-status ${statusClass}">${f.status}</span>
        <div class="audit-content">
          <h4>[${f.id}] ${rule ? rule.name : f.id} (${rule ? rule.standard : 'STD'})</h4>
          <p>${f.details}</p>
        </div>
      `;
      container.appendChild(item);
    });
  }

  document.getElementById('btn-run-audit').addEventListener('click', runAudit);

  // TAB 5: Exporter
  document.getElementById('btn-generate-export').addEventListener('click', () => {
    const target = document.getElementById('export-format').value;
    const nutMs = parseFloat(document.getElementById('nut-select').value) || 5.0;
    let out = '';

    if (target === 'RSNETWORX_CSV') {
      out = `# RSNetWorx for ControlNet Schedule Export\nConnection_ID,Name,Producer_MAC,Consumer_MAC,RPI_ms,Size_Bytes\n`;
      connections.forEach(c => {
        out += `${c.id},"${c.name}",${c.producerMac},${c.consumerMac},${c.rpiMs},${c.dataBytes}\n`;
      });
    } else if (target === 'STUDIO5000_L5X') {
      out = `// Studio 5000 ControlLogix Tag Aliases (1756-CN2R)\n`;
      connections.forEach(c => {
        out += `// Node ${c.producerMac}: ${c.name} (RPI: ${c.rpiMs}ms)\n`;
        out += `ALIAS Tag_Node${c.producerMac}_ScheduledData := Local:2:I.Data[${c.id - 1}]; // ${c.dataBytes} bytes\n`;
      });
    } else if (target === 'PYTHON_SIM') {
      out = `#!/usr/bin/env python3\n# Python 3 ControlNet Scheduled Frame Generator\nimport struct\n\n`;
      out += `def create_scheduled_frame(mac_id=2, conn_id=0x1001, data=b'\\x00'*8):\n`;
      out += `    # Preamble (0xAA55) + Sync (0x7E) + MAC + Conn + Format(0x01)\n`;
      out += `    hdr = struct.pack('>HBBHB', 0xAA55, 0x7E, mac_id, conn_id, 0x01)\n`;
      out += `    print(f"Generated ControlNet Frame for Node {mac_id} (Conn 0x{conn_id:04X})")\n`;
      out += `    return hdr + data\n\n`;
      out += `create_scheduled_frame(2, 0x1001)\n`;
    }

    document.getElementById('export-output').value = out;
  });

  // Init
  renderFrame();
  renderConnsTable();
  recalculateNut();
  runAudit();
});
